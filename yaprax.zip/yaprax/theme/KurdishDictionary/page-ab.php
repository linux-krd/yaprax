<?php
 /**
 *Template Name:about
 */

?>
<?php include(TEMPLATEPATH . '/about/index.html'); ?>
